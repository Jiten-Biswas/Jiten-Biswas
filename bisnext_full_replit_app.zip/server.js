import express from 'express'
import cors from 'cors'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { nanoid } from 'nanoid'
import dotenv from 'dotenv'
import { createServer } from 'http'
import { Server as SocketIOServer } from 'socket.io'
import { db, initDb } from './db.js'

dotenv.config()

const app = express()
const httpServer = createServer(app)
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: '*'
  }
})

const PORT = process.env.PORT || 3000
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-key-change-me'

// Simple in-memory subscription plans
const SUBSCRIPTION_PLANS = {
  free: {
    id: 'free',
    name: 'Free',
    price: 0,
    commissionRate: 0.25, // 25% app commission (example)
    features: ['Basic visibility', 'Standard commission']
  },
  premium: {
    id: 'premium',
    name: 'Premium',
    price: 199,
    commissionRate: 0.2,
    features: ['Higher visibility', 'Lower commission', 'Priority in search']
  },
  pro: {
    id: 'pro',
    name: 'Pro',
    price: 499,
    commissionRate: 0.16,
    features: ['Top visibility', 'Lowest commission', 'Priority support']
  }
}

app.use(cors())
app.use(express.json())
app.use(express.static('public'))

// Initialize DB
await initDb()

// Helper: auth middleware
function auth(requiredRole = null) {
  return (req, res, next) => {
    const authHeader = req.headers.authorization
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid token' })
    }
    const token = authHeader.split(' ')[1]
    try {
      const payload = jwt.verify(token, JWT_SECRET)
      req.user = payload
      if (requiredRole && payload.role !== requiredRole) {
        return res.status(403).json({ error: 'Forbidden: role not allowed' })
      }
      next()
    } catch (err) {
      console.error('JWT verify error', err)
      res.status(401).json({ error: 'Invalid token' })
    }
  }
}

// Utility: find user & safe version
async function findUserById(id) {
  await db.read()
  return db.data.users.find(u => u.id === id)
}

function safeUser(user) {
  if (!user) return null
  const { passwordHash, ...rest } = user
  return rest
}

// --- Health check ---
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'BisNext full Replit backend running' })
})

// --- Auth routes ---

// Register
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, role } = req.body

  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: 'name, email, password, role are required' })
  }

  const validRoles = ['innovator', 'mentor', 'investor', 'business', 'admin']
  if (!validRoles.includes(role)) {
    return res.status(400).json({ error: 'Invalid role' })
  }

  await db.read()
  const existing = db.data.users.find(u => u.email.toLowerCase() === email.toLowerCase())
  if (existing) {
    return res.status(409).json({ error: 'Email already in use' })
  }

  const hashed = await bcrypt.hash(password, 10)
  const user = {
    id: nanoid(),
    name,
    email,
    passwordHash: hashed,
    role,
    createdAt: new Date().toISOString(),
    profile: {
      bio: '',
      skills: [],
      domain: '',
      location: '',
      hourlyRate: null,
      company: '',
      experienceYears: null
    },
    wallet: {
      balance: 0,
      currency: 'INR'
    },
    subscription: {
      planId: 'free',
      startedAt: new Date().toISOString()
    }
  }

  db.data.users.push(user)
  await db.write()

  const token = jwt.sign({ id: user.id, role: user.role, email: user.email }, JWT_SECRET, { expiresIn: '7d' })
  res.json({ token, user: safeUser(user) })
})

// Login
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body
  await db.read()
  const user = db.data.users.find(u => u.email.toLowerCase() === email.toLowerCase())
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' })
  }
  const ok = await bcrypt.compare(password, user.passwordHash)
  if (!ok) {
    return res.status(401).json({ error: 'Invalid credentials' })
  }
  const token = jwt.sign({ id: user.id, role: user.role, email: user.email }, JWT_SECRET, { expiresIn: '7d' })
  res.json({ token, user: safeUser(user) })
})

// Get current user
app.get('/api/me', auth(), async (req, res) => {
  const user = await findUserById(req.user.id)
  if (!user) return res.status(404).json({ error: 'User not found' })
  res.json(safeUser(user))
})

// Update profile
app.put('/api/me/profile', auth(), async (req, res) => {
  const { bio, skills, domain, location, hourlyRate, company, experienceYears } = req.body
  await db.read()
  const user = db.data.users.find(u => u.id === req.user.id)
  if (!user) return res.status(404).json({ error: 'User not found' })

  user.profile.bio = bio ?? user.profile.bio
  user.profile.skills = skills ?? user.profile.skills
  user.profile.domain = domain ?? user.profile.domain
  user.profile.location = location ?? user.profile.location
  user.profile.hourlyRate = hourlyRate ?? user.profile.hourlyRate
  user.profile.company = company ?? user.profile.company
  user.profile.experienceYears = experienceYears ?? user.profile.experienceYears

  await db.write()
  res.json(safeUser(user))
})

// --- Subscription & plans ---
app.get('/api/subscriptions/plans', (req, res) => {
  res.json(Object.values(SUBSCRIPTION_PLANS))
})

app.post('/api/subscriptions/subscribe', auth(), async (req, res) => {
  const { planId } = req.body
  const plan = SUBSCRIPTION_PLANS[planId]
  if (!plan) return res.status(400).json({ error: 'Invalid planId' })

  await db.read()
  const user = db.data.users.find(u => u.id === req.user.id)
  if (!user) return res.status(404).json({ error: 'User not found' })

  // MOCK PAYMENT: no real gateway, just record transaction
  const tx = {
    id: nanoid(),
    userId: user.id,
    type: 'subscription',
    amount: plan.price,
    currency: 'INR',
    meta: { planId: plan.id },
    status: 'success',
    createdAt: new Date().toISOString()
  }
  db.data.transactions.push(tx)

  user.subscription = {
    planId: plan.id,
    startedAt: new Date().toISOString()
  }

  await db.write()
  res.json({ subscription: user.subscription, transaction: tx })
})

// --- Wallet & mock payments ---

app.get('/api/wallet', auth(), async (req, res) => {
  await db.read()
  const user = db.data.users.find(u => u.id === req.user.id)
  if (!user) return res.status(404).json({ error: 'User not found' })
  res.json(user.wallet)
})

// Mock endpoint to credit wallet (e.g., mentor earnings or manual top-up)
app.post('/api/wallet/mock-credit', auth(), async (req, res) => {
  const { amount, reason } = req.body
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Positive amount required' })
  await db.read()
  const user = db.data.users.find(u => u.id === req.user.id)
  if (!user) return res.status(404).json({ error: 'User not found' })

  user.wallet.balance += Number(amount)
  const tx = {
    id: nanoid(),
    userId: user.id,
    type: 'wallet_credit',
    amount: Number(amount),
    currency: 'INR',
    meta: { reason: reason || 'manual_mock' },
    status: 'success',
    createdAt: new Date().toISOString()
  }
  db.data.transactions.push(tx)
  await db.write()
  res.json({ wallet: user.wallet, transaction: tx })
})

// Wallet transactions
app.get('/api/wallet/transactions', auth(), async (req, res) => {
  await db.read()
  const txs = db.data.transactions.filter(t => t.userId === req.user.id)
  res.json(txs)
})

// --- Posts & feed (with boost flag) ---

// Create post (all roles allowed)
app.post('/api/posts', auth(), async (req, res) => {
  const { content, type } = req.body
  if (!content) return res.status(400).json({ error: 'content required' })

  await db.read()
  const post = {
    id: nanoid(),
    userId: req.user.id,
    role: req.user.role,
    content,
    type: type || 'text',
    isBoosted: false,
    createdAt: new Date().toISOString()
  }
  db.data.posts.unshift(post)
  await db.write()
  res.json(post)
})

// Boost a post (mock payment)
app.post('/api/posts/:id/boost', auth(), async (req, res) => {
  const BOOST_COST = 299
  await db.read()
  const post = db.data.posts.find(p => p.id === req.params.id)
  if (!post) return res.status(404).json({ error: 'Post not found' })
  if (post.userId !== req.user.id) return res.status(403).json({ error: 'Not your post' })

  post.isBoosted = true

  const tx = {
    id: nanoid(),
    userId: req.user.id,
    type: 'boost',
    amount: BOOST_COST,
    currency: 'INR',
    meta: { postId: post.id },
    status: 'success',
    createdAt: new Date().toISOString()
  }
  db.data.transactions.push(tx)

  await db.write()
  res.json({ post, transaction: tx })
})

// Get feed (boosted first)
app.get('/api/posts', async (req, res) => {
  await db.read()
  const { role, limit = 50 } = req.query
  let posts = db.data.posts

  if (role) {
    posts = posts.filter(p => p.role === role)
  }

  // Sort: boosted first, then newest
  posts = posts.sort((a, b) => {
    if (a.isBoosted && !b.isBoosted) return -1
    if (!a.isBoosted && b.isBoosted) return 1
    return new Date(b.createdAt) - new Date(a.createdAt)
  })

  posts = posts.slice(0, Number(limit))
  res.json(posts)
})

// --- Mentorship sessions & meetings ---

// Create mentorship session request (innovator/business -> mentor)
app.post('/api/sessions', auth(), async (req, res) => {
  const { mentorId, topic, scheduledAt, durationMinutes, meetingMode } = req.body
  if (!mentorId || !topic || !scheduledAt || !durationMinutes) {
    return res.status(400).json({ error: 'mentorId, topic, scheduledAt, durationMinutes required' })
  }

  await db.read()
  const mentor = db.data.users.find(u => u.id === mentorId && u.role === 'mentor')
  if (!mentor) return res.status(404).json({ error: 'Mentor not found' })

  const session = {
    id: nanoid(),
    requesterId: req.user.id,
    mentorId,
    topic,
    scheduledAt,
    durationMinutes,
    meetingMode: meetingMode || 'online',
    status: 'pending', // pending -> accepted -> completed/cancelled
    createdAt: new Date().toISOString(),
    meetingLink: null
  }

  db.data.sessions.push(session)
  await db.write()
  res.json(session)
})

// List my sessions
app.get('/api/sessions', auth(), async (req, res) => {
  await db.read()
  const sessions = db.data.sessions.filter(
    s => s.requesterId === req.user.id || s.mentorId === req.user.id
  )
  res.json(sessions)
})

// Mentor updates session status (accept/decline/complete/cancel)
app.patch('/api/sessions/:id/status', auth(), async (req, res) => {
  const { status } = req.body
  const allowed = ['accepted', 'declined', 'completed', 'cancelled']
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' })
  }

  await db.read()
  const session = db.data.sessions.find(s => s.id === req.params.id)
  if (!session) return res.status(404).json({ error: 'Session not found' })

  // Only mentor or requester can change certain states; keep it simple for now
  if (req.user.id !== session.mentorId && req.user.id !== session.requesterId) {
    return res.status(403).json({ error: 'Not part of this session' })
  }

  session.status = status
  await db.write()
  res.json(session)
})

// Attach meeting link (mentor action)
app.post('/api/sessions/:id/meeting-link', auth(), async (req, res) => {
  const { meetingLink } = req.body
  if (!meetingLink) return res.status(400).json({ error: 'meetingLink required' })

  await db.read()
  const session = db.data.sessions.find(s => s.id === req.params.id)
  if (!session) return res.status(404).json({ error: 'Session not found' })
  if (session.mentorId !== req.user.id) {
    return res.status(403).json({ error: 'Only mentor can set meeting link' })
  }

  session.meetingLink = meetingLink
  await db.write()
  res.json(session)
})

// --- Simple in-DB chat + Socket.io for real-time ---

// Create or get chat between two users
app.post('/api/chats', auth(), async (req, res) => {
  const { otherUserId } = req.body
  if (!otherUserId) return res.status(400).json({ error: 'otherUserId required' })

  await db.read()
  let chat = db.data.chats.find(
    c => c.participantIds.includes(req.user.id) && c.participantIds.includes(otherUserId)
  )
  if (!chat) {
    chat = {
      id: nanoid(),
      participantIds: [req.user.id, otherUserId],
      createdAt: new Date().toISOString()
    }
    db.data.chats.push(chat)
    await db.write()
  }
  res.json(chat)
})

// Send message
app.post('/api/chats/:chatId/messages', auth(), async (req, res) => {
  const { text } = req.body
  if (!text) return res.status(400).json({ error: 'text required' })
  await db.read()
  const chat = db.data.chats.find(c => c.id === req.params.chatId)
  if (!chat) return res.status(404).json({ error: 'Chat not found' })
  if (!chat.participantIds.includes(req.user.id)) {
    return res.status(403).json({ error: 'Not your chat' })
  }
  const message = {
    id: nanoid(),
    chatId: chat.id,
    senderId: req.user.id,
    text,
    createdAt: new Date().toISOString()
  }
  db.data.messages.push(message)
  await db.write()

  // Emit via Socket.io
  io.to(chat.id).emit('chat:message', message)

  res.json(message)
})

// Get messages in a chat
app.get('/api/chats/:chatId/messages', auth(), async (req, res) => {
  await db.read()
  const chat = db.data.chats.find(c => c.id === req.params.chatId)
  if (!chat) return res.status(404).json({ error: 'Chat not found' })
  if (!chat.participantIds.includes(req.user.id)) {
    return res.status(403).json({ error: 'Not your chat' })
  }
  const messages = db.data.messages.filter(m => m.chatId === chat.id)
  res.json(messages)
})

// Socket.io connections
io.on('connection', socket => {
  console.log('Socket connected', socket.id)

  socket.on('chat:join', chatId => {
    socket.join(chatId)
  })

  socket.on('disconnect', () => {
    console.log('Socket disconnected', socket.id)
  })
})

// --- Simple search users ---
app.get('/api/users', async (req, res) => {
  const { role, q } = req.query
  await db.read()
  let users = db.data.users.map(u => safeUser(u))

  if (role) {
    users = users.filter(u => u.role === role)
  }
  if (q) {
    const query = q.toLowerCase()
    users = users.filter(
      u =>
        u.name.toLowerCase().includes(query) ||
        (u.profile?.domain || '').toLowerCase().includes(query) ||
        (u.profile?.bio || '').toLowerCase().includes(query)
    )
  }
  res.json(users)
})

// Fallback route
app.get('/api/*', (req, res) => {
  res.status(404).json({ error: 'API route not found' })
})

httpServer.listen(PORT, () => {
  console.log(`Server with Socket.io listening on port ${PORT}`)
})
