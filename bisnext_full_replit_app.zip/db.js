import { Low } from 'lowdb'
import { JSONFile } from 'lowdb/node'

// File path for JSON database
const adapter = new JSONFile('db.json')

const defaultData = {
  users: [],
  posts: [],
  sessions: [],
  chats: [],
  messages: [],
  transactions: [],
  meetings: [],
  notifications: []
}

export const db = new Low(adapter, defaultData)

export async function initDb() {
  await db.read()
  db.data ||= defaultData
  await db.write()
}
