# BisNext Full Replit Backend (Auth + Posts + Sessions + Chat + Wallet + Subscriptions)

This is a more complete **backend skeleton** for your Innovator–Mentor–Investor–Business platform,
designed to run directly on **Replit**.

> It is not connected to real payment gateways or email/SMS providers.
> Instead, it includes **mock payment & wallet flows** and all the main endpoints
> so you (or a future dev/AI) can plug in Razorpay/Stripe, email, etc.

## Features Included

- Node.js + Express backend (ESM)
- Socket.io server for real-time chat events
- File-based JSON database using **lowdb** (no external DB required for testing)
- User auth (register/login) with roles:
  - `innovator`, `mentor`, `investor`, `business`, `admin`
- User profile update (bio, skills, domain, location, hourlyRate, etc.)
- Basic **subscription plans** (free, premium, pro) with mock payment endpoint
- **Wallet** per user with:
  - Balance tracking
  - Mock credit endpoint
  - Transaction history
- **Posts & feed**:
  - Create posts (text)
  - Fetch feed (boosted posts appear first)
  - Boost posts (mock payment, records transaction)
- **Mentorship sessions**:
  - Create session request (innovator/business -> mentor)
  - List my sessions
  - Update status (accepted / declined / completed / cancelled)
  - Attach video meeting link (e.g., Google Meet / Zoom / Jitsi URL)
- **Chat**:
  - Create or get 1:1 chat
  - Send messages
  - Load messages
  - Real-time broadcast via Socket.io (`chat:message` events per chat room)
- Simple user search (`/api/users?role=mentor&q=python`)

## How to Use on Replit

1. Create a new **Node.js Repl**.
2. Upload and **extract this zip** into the Repl (replace default files).
3. Open the Replit shell and install deps:

   ```bash
   npm install
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open the web view – you'll see the helpful API overview page.

6. Use a REST client (Postman, Thunder Client, Insomnia) to call the `/api/*` endpoints.

### Example Flow to Test Quickly

1. **Register** as mentor:
   - `POST /api/auth/register`
   - Body: `{ "name": "Mentor One", "email": "m1@test.com", "password": "test123", "role": "mentor" }`

2. **Register** as innovator:
   - `POST /api/auth/register`
   - Body: `{ "name": "Innovator One", "email": "i1@test.com", "password": "test123", "role": "innovator" }`

3. **Login** as innovator, get JWT token.

4. **Create post** with token:
   - `POST /api/posts`

5. **Request session** with mentor:
   - `POST /api/sessions`

6. **Login** as mentor, **accept** the session:
   - `PATCH /api/sessions/:id/status`

7. Create a **chat** and **send messages** between innovator and mentor.

You can now extend this backend with:

- Real payment gateway (Razorpay/Stripe)
- Proper cron-based reminders & notifications
- Email/SMS integrations
- External or managed database (PostgreSQL, etc.)
- A full frontend (web + mobile) consuming these APIs.
